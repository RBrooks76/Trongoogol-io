          </div>
        </div>
      </div>
    </div>

    <script src="<?php echo base_url();?>ajqgzgmedscuoc/admin/vendors/js/core/jquery-3.2.1.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>ajqgzgmedscuoc/admin/vendors/js/core/popper.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>ajqgzgmedscuoc/admin/vendors/js/core/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>ajqgzgmedscuoc/admin/vendors/js/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>ajqgzgmedscuoc/admin/vendors/js/prism.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>ajqgzgmedscuoc/admin/vendors/js/jquery.matchHeight-min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>ajqgzgmedscuoc/admin/vendors/js/screenfull.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>ajqgzgmedscuoc/admin/vendors/js/pace/pace.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>ajqgzgmedscuoc/admin/js/app-sidebar.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>ajqgzgmedscuoc/admin/js/notification-sidebar.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>ajqgzgmedscuoc/admin/js/customizer.js" type="text/javascript"></script>

    <script src="<?php echo front_url(); ?>ajqgzgmedscuoc/admin/js/jquery.validate.min.js" type="text/javascript"></script>
    <script src="<?php echo front_url(); ?>ajqgzgmedscuoc/admin/js/login.js?ver=<?php echo date('U');?>" type="text/javascript"></script>
  
    <script src="<?php echo front_url(); ?>ajqgzgmedscuoc/admin/js/pattern/script.js?ver=<?php echo date('U');?>" type="text/javascript"></script>
    <script src="<?php echo front_url(); ?>ajqgzgmedscuoc/admin/js/pattern/script1.js?ver=<?php echo date('U');?>" type="text/javascript"></script>

    <script type="text/javascript">
        var base_url = "<?php echo base_url();?>"
    </script>

  </body>
</html>